import { Dimensions, StyleSheet } from "react-native";

const {width, height} = Dimensions.get('window');   
const styles = StyleSheet.create({
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        borderColor: '#EBF0FF',
        borderWidth: 1,
        height: 48,
        borderRadius: 5,
        marginTop: 4,
        paddingStart: 8,
        backgroundColor: 'white',
        width: width - 32
    },
    textInputStyle: {
        flex: 1,
        color: '#9098B1',
        fontWeight: '400',
        fontSize: 12,
        letterSpacing: 0.5,

        paddingHorizontal: 8
    },
    imageStyle: {
        width: 18,
        height: 14,
        resizeMode: 'contain',
        margin: 10,
        alignItems: 'center',
    },
    icon: {
        height: 20,
        width: 20,
    }
})

export default styles;