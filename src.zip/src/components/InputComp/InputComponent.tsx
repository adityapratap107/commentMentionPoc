import {Image, TextInput, View, ViewStyle} from 'react-native';
import React from 'react';
import styles from './styles';

interface TextInputProps {
  placeholderValue: string;
  keyboardType: string;
  autoCapitalize: boolean;
  onChangeText: () => {};
  inputStyle: ViewStyle;
  placeholderTextColor: string;
  value: string;
  secureTextEntry: boolean;
  imgPath: string;
  ref: object;
  onFocus: () => {};
  focusStyle: ViewStyle
}

const InputComponent = ({
  placeholderValue,
  keyboardType,
  autoCapitalize,
  onChangeText,
  inputStyle,
  placeholderTextColor,
  value,
  secureTextEntry,
  imgPath,
  ref,
  onFocus,
}: TextInputProps) => {
  return (
    <View style={[styles.inputContainer, inputStyle]}>
      <Image source={imgPath} style={styles.icon} />
      <TextInput
      ref={ref}
        style={[styles.textInputStyle]}
        placeholder={placeholderValue}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        placeholderTextColor={placeholderTextColor}
        autoCapitalize={autoCapitalize}
        onChangeText={value => {
          onChangeText(value);
        }}
        value={value}
        onFocus={onFocus}
      />
    </View>
  );
};

export default InputComponent;
